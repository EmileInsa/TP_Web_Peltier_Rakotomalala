<?php

function getPublishedPostsByTopic($topic_id) {
    global $conn;
    $sql = "SELECT * FROM posts WHERE id IN (
                SELECT post_id FROM post_topic WHERE topic_id = $topic_id
            ) AND published = true";
    
    $result = mysqli_query($conn, $sql);
    $final_posts = array();
    if(mysqli_num_rows($result) > 0) {

        while($row = mysqli_fetch_assoc($result)) {
            $row['topic'] = getPostTopic($row['id']);
            $final_posts[] = $row;
        }
    }
    return $final_posts;
}

function getPublishedPosts() {
    global $conn;
    
    $query = "SELECT * FROM posts WHERE published=true";
    $result = mysqli_query($conn, $query);

    $posts = array();
    while ($row = mysqli_fetch_assoc($result)) {
        // Appel de getPostTopic pour chaque article
        $topic = getPostTopic($row['id']);
        // Ajout du topic à l'article
        $row['topic'] = $topic;
        // Suppression du champ 'body' de l'article
        unset($row['body']);
        // Ajout de l'article au tableau des articles
        $posts[] = $row;
    }

    return $posts;
}

function getPostTopic($post_id){
    global $conn;
    $sql = "SELECT topics.* FROM topics JOIN posts ON topics.id = posts.id WHERE posts.id = '$post_id'";
    $result = mysqli_query($conn, $sql);
    $topic = mysqli_fetch_assoc($result);
    return $topic;
}

/*<?php 
function getPublishedPosts() {
    global $conn;
    
    $query = "SELECT * FROM posts WHERE published=true";
    $result = mysqli_query($conn, $query);

    $posts = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $posts[] = $row;
    }

    return $posts;
}

function getPostTopic($post_id){
    global $conn;
    $sql = "SELECT * FROM topics JOIN posts ON topics.id = posts.topic_id WHERE posts.id = '$post_id'";
    $result = mysqli_query($conn, $sql);
    $topic = mysqli_fetch_assoc($result);
    return $topic;
}*/

function getAllTopics() {
    global $conn;
    $query = "SELECT * FROM topics";
    $result = mysqli_query($conn, $query);
    $topics = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $topics;
}

function getPost($slug) {
    global $conn;
    
    // Préparer la requête SQL pour récupérer les détails du post en fonction du slug
    $query = "SELECT * FROM posts WHERE slug = '$slug'";
    $result = mysqli_query($conn, $query);

    // Vérifier s'il y a des résultats
    if (mysqli_num_rows($result) > 0) {
        // Récupérer les données du post
        $post = mysqli_fetch_assoc($result);
        return $post;
    } else {
        // Retourner false si aucun post trouvé
        return false;
    }
}
