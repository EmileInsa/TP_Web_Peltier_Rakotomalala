<?php
if (isset($errors)) {
    foreach ($errors as $error) {
        echo "- $error\n";
    }
}
?>
