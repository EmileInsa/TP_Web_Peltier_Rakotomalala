<?php
// variable declaration
$username = "";
$email = "";
$errors = array();

if (isset($_POST['register_btn'])) {
    $username = esc($_POST['username']);
    $email = esc($_POST['email']);
    $password = esc($_POST['password']);
    $password_confirm = esc($_POST['password_confirm']);
    if (empty($username)) {
    array_push($errors, "Username required");
    }
    if (empty($email)) {
        array_push($errors, "email required");
    }
    if (empty($password)) {
        array_push($errors, "Password required");
    }
    if (empty($password_confirm)) {
        array_push($errors, "confirm password required");
    }
    if ($password !== $password_confirm) {
    array_push($errors, "not same password");
    }

    // Vérifier l'unicité du couple (username, email) avant d'inscrire l'utilisateur
$sql_check_unique = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
$result_check_unique = mysqli_query($conn, $sql_check_unique);
$user_check_unique = mysqli_fetch_assoc($result_check_unique);
    if ($user_check_unique) {
        if ($user_check_unique['username'] === $username) {
            array_push($errors, "Username already exists");
        }
        if ($user_check_unique['email'] === $email) {
            array_push($errors, "Email already exists");
        }
    }

    
    if (empty($errors)) {
        $password = md5($password); // encrypt password
        $sql = "INSERT INTO users (`username`, `email`, `password`) VALUES ('$username', '$email', '$password')";

        var_dump($sql);
        mysqli_query($conn, $sql);
     
    }
}





// LOG USER IN
    if (isset($_POST['login_btn'])) {
    $username = esc($_POST['username']);
    $password = esc($_POST['password']);
    if (empty($username)) {
        array_push($errors, "Username required");
    }
    if (empty($password)) {
        array_push($errors, "Password required");
    }
    if (empty($errors)) {
        $password = md5($password); // encrypt password
        $sql = "SELECT * FROM users WHERE username='$username' and password='$password' LIMIT 1";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            // get id of created user
            $reg_user_id = mysqli_fetch_assoc($result)['id'];
            //var_dump(getUserById($reg_user_id)); die();
            // put logged in user into session array
            $_SESSION['user'] = getUserById($reg_user_id);
            
            // if user is admin, redirect to admin area
            if (in_array($_SESSION['user']['role'], ["Admin", "Author"])) {
                $_SESSION['message'] = "You are now logged in";
                // redirect to admin area
                header('location: ' . BASE_URL . '/admin/dashboard.php');
                exit(0);
            } else {
                $_SESSION['message'] = "You are now logged in";
                // redirect to public area
                header('location: index.php');
                exit(0);
                }
                
        } else {
                array_push($errors, 'Wrong credentials');
        }
    }
}
// Get user info from user id
function getUserById($id) {
global $conn; //rendre disponible, à cette fonction, la variable de connexion $conn
$sql = "SELECT * FROM users WHERE id='$id'"; // requête qui récupère le user et son rôle
$result =mysqli_query($conn, $sql); //la fonction php-mysql
$user = mysqli_fetch_assoc($result);//je met $result au format associatif
return $user;
}

function esc( $val){
    
    return $val;
}