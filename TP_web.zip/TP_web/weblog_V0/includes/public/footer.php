<div class="footer">
	<p>My Web Site &copy; <?php echo date('Y'); ?></p>
</div>

</body>
</html>
