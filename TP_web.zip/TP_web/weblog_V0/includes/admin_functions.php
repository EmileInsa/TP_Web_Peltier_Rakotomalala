// admin_functions.php

<?php
// Vérifier si l'utilisateur est un administrateur
function isAdmin($user) {
    return isset($user['role']) && $user['role'] == 'Admin';
}
?>

<?php




function getAdminRoles() {
    global $conn;

    // Vérifier la connexion à la base de données
    if (!$conn) {
        die("Erreur de connexion à la base de données : " . mysqli_connect_error());
    }

    // Requête pour récupérer les rôles des administrateurs
    $sql = "SELECT * FROM roles";

    // Exécuter la requête
    $result = mysqli_query($conn, $sql);

    // Vérifier les erreurs de requête
    if (!$result) {
        die("Erreur de requête : " . mysqli_error($conn));
    }

    // Vérifier s'il y a des résultats
    if(mysqli_num_rows($result) > 0) {
        $roles = array();

        // Parcourir les résultats et les ajouter à un tableau
        while($row = mysqli_fetch_assoc($result)) {
            $roles[] = $row;
        }

        return $roles;
    } else {
        // Aucun rôle trouvé
        return false;
    }
}

function getAdminUsers() {
    global $conn;

    // Vérifier la connexion à la base de données
    if (!$conn) {
        die("Erreur de connexion à la base de données : " . mysqli_connect_error());
    }

    // Requête pour récupérer les utilisateurs et leur rôle
    $sql = "SELECT users.username, users.email, roles.name AS role FROM users INNER JOIN roles ON users.role = roles.name";

    // Exécuter la requête
    $result = mysqli_query($conn, $sql);

    // Vérifier les erreurs de requête
    if (!$result) {
        die("Erreur de requête : " . mysqli_error($conn));
    }

    // Vérifier s'il y a des résultats
    if(mysqli_num_rows($result) > 0) {
        $users = array();

        // Parcourir les résultats et les ajouter à un tableau
        while($row = mysqli_fetch_assoc($result)) {
            $users[] = $row;
        }

        return $users;
    } else {
        // Aucun utilisateur trouvé
        return false;
    }
}




?>