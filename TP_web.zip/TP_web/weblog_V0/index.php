<?php
include('config.php');
include('includes/public/head_section.php');
include('includes/public/registration_login.php'); 
include('includes/public/register.php'); 
include('includes/all_functions.php');


$title = "MyWebSite | Home";

?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
</head>
<body>
    <div class="container">
        <!-- Navbar -->
        <?php include(ROOT_PATH . '/includes/public/navbar.php'); ?>
        <!-- // Navbar -->
        <!-- Banner -->
        <?php include(ROOT_PATH . '/includes/public/banner.php'); ?>
        <!-- // Banner -->
        <!-- Messages -->
        <!-- // Messages -->
        <!-- content -->
        <div class="content">
            <h2 class="content-title">Recent Articles</h2>
            <hr>
            <?php $published_posts= getPublishedPosts(); ?>
            <?php foreach ($published_posts as $post): ?>
                <div class="post" style="margin-left: 0px;">
                    <img src="<?php echo BASE_URL . '/static/images/' . $post['image']; ?>" class="post_image" alt="">
                    <a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">
                        <h3 class="post_title"><?php echo $post['title']; ?></h3>
                    </a>
                    <div class="post_info">
                        <span><?php echo $post['author']; ?> | <?php echo $post['topic']; ?></span>
                        <span><?php echo date("F j, Y", strtotime($post['created_at'])); ?></span>
                        <a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">Read more</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- // content -->
    </div>
    <!-- // container -->
    <!-- Footer -->
    <?php include(ROOT_PATH . '/includes/public/footer.php'); ?>
    <!-- // Footer -->
</body>
</html>
