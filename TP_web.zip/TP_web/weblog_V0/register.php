<?php include('config.php'); ?>

<?php include('includes/public/registration_login.php'); ?>

<?php include('includes/public/head_section.php'); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyWebSite | Sign up </title>
</head>
<body>

	<div class="container">

		<!-- Navbar -->
		<?php include(ROOT_PATH . '/includes/public/navbar.php'); ?>
		<!-- // Navbar -->


		<div style="width: 40%; margin: 20px auto;">
			<form method="post" action="">
				<h2>Sign up</h2>
				<?php if (!empty($errors)): ?>
					<ul style="color: red;">
						<?php foreach ($errors as $error): ?>
							<li><?php echo $error; ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<input type="text" name="username" placeholder="username" value="<?php echo isset($username) ? $username : ''; ?>">

				<input type="email" name="email" placeholder="email" value="<?php echo isset($email) ? $email : ''; ?>">

				<input type="password" name="password" placeholder="password">

				<input type="password" name="password_confirm" placeholder="confirm password">

				<button type="submit" class="btn" name="register_btn">Sign up</button>
				<p>
					Already a member? <a href="login.php">Sign in</a>
				</p>
			</form>
		</div>

	</div>
	<!-- // container -->

	<!-- Footer -->
	<?php include(ROOT_PATH . '/includes/public/footer.php'); ?>
	<!-- // Footer -->

</body>
</html>
