<?php
include('config.php');
include('includes/all_functions.php');

if(isset($_GET['topic'])) {
    $topic_id = $_GET['topic'];
    $posts = getPublishedPostsByTopic($topic_id);
    include('includes/public/head_section.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Filtered Posts | MyWebSite</title>
    <!-- Vos balises meta, CSS, etc. -->
</head>
<body>
    <div class="container">
        <!-- Navbar -->
        <?php include(ROOT_PATH . '/includes/public/navbar.php'); ?>
        <!-- // Navbar -->
        <div class="content">
            <h2 class="content-title">Filtered Posts</h2>
            <hr>
            <?php foreach ($posts as $post): ?>
                <div class="post" style="margin-left: 0px;">
                    <img src="<?php echo BASE_URL . '/static/images/' . $post['image']; ?>" class="post_image" alt="">
                    <a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">
                        <h3 class="post_title"><?php echo $post['title']; ?></h3>
                    </a>
                    <div class="post_info">
                        <span><?php echo $post['author']; ?> | <?php echo $post['topic']; ?></span>
                        <span><?php echo date("F j, Y", strtotime($post['created_at'])); ?></span>
                        <a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">Read more</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- // content -->
        <!-- Footer -->
        <?php include(ROOT_PATH . '/includes/public/footer.php'); ?>
        <!-- // Footer -->
    </div>
</body>
</html>
<?php
} else {
    header("Location: index.php");
    exit();
}
?>
