<?php 
include('config.php');
include('includes/public/head_section.php');
include('includes/all_functions.php');

// Vérifiez si le slug du post est défini dans l'URL
if (isset($_GET['post-slug'])) {
    // Récupérer le slug du post depuis l'URL
    $post_slug = $_GET['post-slug'];
    
    // Récupérer les détails du post en fonction du slug
    $post = getPost($post_slug);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo isset($post['title']) ? $post['title'] : 'MyWebSite'; ?> | MyWebSite</title>
    <!-- Vos balises meta, CSS, etc. -->
</head>
<body>
    <div class="container">
        <!-- Navbar -->
        <?php include(ROOT_PATH . '/includes/public/navbar.php'); ?>
        <!-- // Navbar -->
        <div class="content">
            <div class="post-wrapper">
                <!-- full post div -->
                <div class="full-post-div">
                    <?php if (isset($post)): ?>
                        <h2 class="post-title"><?php echo $post['title']; ?></h2>
                        <div class="post-body-div">
                            <?php echo $post['body']; ?>
                        </div>
                    <?php else: ?>
                        <p>Post not found.</p>
                    <?php endif; ?>
                </div>
                <!-- // full post div -->
            </div>
            <!-- // Page wrapper -->
            <!-- post sidebar -->
            <div class="post-sidebar">
                <div class="card">
                    <div class="card-header">
                        <h2>Topics</h2>
                    </div>
                    <div class="card-content">
                        <?php
                            // Récupération des topics depuis la base de données
                            $topics = getAllTopics();
                            foreach ($topics as $topic) {
                                echo "<a href='filtered_posts.php?topic={$topic['id']}'>{$topic['name']}</a><br>";
                            }
                        ?>
                    </div>
                </div>
            </div>
            <!-- // post sidebar -->
        </div>
        <!-- // content -->
        <?php include(ROOT_PATH . '/includes/public/footer.php'); ?>
    </div>
</body>
</html>
